package cl.desafiolatam.desafiobiblioteca



    data class LibrosEscolares(
        val nombre: String, val ISBM: Long, val añoPublicacion: Int,
        val editorial: String, val cantidadPaginas: Int, val precio: Int,
        val autorLibro: String, var tipoDeLibro: Char)









